package Controlers;

public class SynchronizationControler {
	
	public SynchronizationControler() {
		
	}

}
