package Events;

import java.beans.EventHandler;
import java.util.EventObject;

public class NetworkControlerEvent extends EventObject{

	public NetworkControlerEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
