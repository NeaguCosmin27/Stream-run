package GUI;

import javax.swing.JPanel;

public class FileSynchronization extends JPanel{
	
	
	public FileSynchronization() {
		
	}

}
