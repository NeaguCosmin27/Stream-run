package Listeners;

public interface CurrentMachineExplorerControlsListener {
	public void getHierarchicalPath(String hierarchicalPath);
}
