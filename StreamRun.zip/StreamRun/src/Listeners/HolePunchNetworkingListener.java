package Listeners;

public interface HolePunchNetworkingListener {
     public void getServerConnectionStatus(String status, boolean isSetup);
}
