package Listeners;

public interface RemoteFileTransferControlerListener {
     public void getServerConnectionStatus(String status, boolean isSetup);
}
