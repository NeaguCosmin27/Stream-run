package Listeners;

public interface SourceDialogListener {
      public void enableMainframe();
      public void startSource(String IP, int port, String name, String selectedFilePath, String hostname);
}
