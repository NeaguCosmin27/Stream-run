package Networking;

import java.net.ServerSocket;
import java.net.Socket;

public class SessionHandler extends Thread{
	
	private Socket serverConnectionSocket;
	private ServerSocket socketFromPeer;
	private Socket socketToPeer;
	
	public SessionHandler(Socket serverConnectionSocket) {
		
	}
	
	public void run() {
		
	}

}
